<?php
$jh_conn = mysqli_connect( 'localhost', 'root', '', 'mydb' );
?>