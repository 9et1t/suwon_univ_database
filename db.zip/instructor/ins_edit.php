﻿<?php
  include "./db1.php";
  $edit_staff_no = $_POST[ 'edit_staff_no' ];
  $jh_sql_edit = "SELECT * FROM staff WHERE idStaff = $edit_staff_no;";
  $jh_result = mysqli_query( $jh_conn, $jh_sql_edit );
  $jh_row = mysqli_fetch_array( $jh_result );
?>
 
<!doctype html>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <title>staff edit</title>
    <style>
      body {
        font-family: Consolas, monospace;
        font-family: 12px;
      }
    </style>
  </head>
  <body>
<form action="ins_edit_ok.php" method="post" enctype="multipart/form-data">
<h1>강사 수정</h1>
       
       </select> 
      <input type="hidden" name="staff_no" value="<?php echo $jh_row[ 'idStaff' ] ; ?>"></br></br>
      <b>이  름&nbsp <input type="text" name="name" value="<?php echo $jh_row[ 'name' ]; ?>" required></b></br></br>
      <b>고용일 <input type="date" name="hired_date" value="<?php echo $jh_row[ 'hired_date']; ?>" required></b></br></br>
      <b>핸드폰 <input type="text" name="S_phone" value="<?php echo $jh_row[ 'S_phone' ]; ?>" required></b></br></br>
      <input type='submit' style='width:80px; height:30px; background-color:white; border-color:black; border-radius:30px;' value='수정 완료'  > 

   </form>
</html>