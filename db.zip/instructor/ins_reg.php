﻿<?php

include "./db1.php";

?>
<!doctype html>
<head>
<meta charset="UTF-8">
<title>Staff_reg</title>
<form action="ins_reg_ok.php" method="post" enctype="multipart/form-data">
<h1>강사 등록</h1>
      <p>이  름 &nbsp&nbsp<input type="text" name="name" required></p>
      <p>채용일 <input type="date" name="hired_date" required></p>
      <p>핸드폰 <input type="text" name="S_phone" required></p>
      <input type='submit' style='width:80px; height:30px; background-color:white; border-color:black; border-radius:30px;' value='강사 등록'  >
 
   </form>
</html>

