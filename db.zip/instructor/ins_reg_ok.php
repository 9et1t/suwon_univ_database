﻿<?php
include "./db1.php"
?>
<!doctype html>
<html>
<?php

$name=$_POST['name'];
$hired_date=$_POST['hired_date']; 
$phone=$_POST['S_phone'];

//$sql1 = "select ID from lesson where name='$lesson'";
//$result1 = mysqli_query($jh_conn,$sql1);
//$row1 = mysqli_fetch_assoc($result1);
//$a = $row1['ID'];

$sql = "insert into staff (name,hired_date,S_phone) values ('$name','$hired_date','$phone')";

  if($jh_conn->query($sql)){
    echo "<script>alert (강사 등록이 완료되었습니다.');</script>";
   }
 else echo "<script>alert (강사 등록이 실패했습니다.');</script>";
?>
<meta http-equiv="refresh" content="0; url=./ins.php">
</html>