﻿<?php
include "./db1.php";
?>

<!doctype html>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <title>Update Staff</title>
    <style>
      body {
        font-family: Consolas, monospace;
        font-family: 12px;
      }
    </style>
  </head>
  <body>
    <?php
      $staff_no = $_POST[ 'staff_no' ];
      $name = $_POST[ 'name' ];
      $hired_date = $_POST[ 'hired_date' ];
      $S_phone = $_POST[ 'S_phone' ];

//      $sql1 = "select ID from lesson where name='$lesson'";
 //     $result1 = mysqli_query($jh_conn,$sql1);
 //     $row1 = mysqli_fetch_assoc($result1);
  //    $a = $row1['ID'];

      if ( is_null( $staff_no ) ) {
        echo '<h1>Fail!</h1>';
      } else {
        $jh_sql = "UPDATE staff SET name = '$name', hired_date = '$hired_date', S_phone = '$S_phone' WHERE idStaff = $staff_no;";
        mysqli_query( $jh_conn, $jh_sql );
      }
    ?>
<meta http-equiv="refresh" content="0; url=./ins.php">
  </body>
</html>