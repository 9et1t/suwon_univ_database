﻿<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>점검 정보</title>
  </head>
  <body>
    <?php
      $conn = mysqli_connect("localhost","root","") ;
      $dbname="mydb";
      mysqli_select_db($conn,$dbname); 
    ?>

<!doctype html>
<html>
<head>

</head>
<body>

  <style>
      body {
        font-family: Consolas, monospace;
        font-family: 12px;
      }
      table {
        width: 100%;
      }
      th, td {
        padding: 10px;
        border-bottom: 1px solid #dadada;
        text-align: center;
      }
    </style>

<article>
   

	<center><h1> 점검 정보 </h1></center>

          <table>
            <tr>
              <th>
                직원 이름
              </th>
              <th>
                 기구 이름
              </th>
              <th>
                 점검 날짜
              </th>
              <th>
                점검 회사
              </th>
            </tr>
            
	<?php
              
	$sql = "select A.name'staff',C.name'equipment',B.date,B.company from staff A inner join s_check B inner join fitness_e C where A.idStaff = Staff_idStaff and B.Fitness_E_F_id = C.F_id";   
              $result = mysqli_query($conn,$sql);

	
	while($row = mysqli_fetch_assoc($result)){
              $staff = $row['staff'];
 	$equipment = $row['equipment'];
	$date = $row['date'];
	$company = $row['company'];
 	
	
                
               
                echo "
                    <tr>
                      <td>
                        {$staff}
                      </td>
                      <td>
		 {$equipment}
                	
                      </td>
                      <td>
		{$date}
                    
                      </td>
                       <td>
		{$company}
		
                      
                          </td>
                    </tr>
                ";
              }
                ?>
<a href="check_reg.php"><button style='width:80px; height:30px; background-color:white; border-color:black; border-radius:30px;'>안전 점검</button></a>
 </article>  
</html>
</body>
