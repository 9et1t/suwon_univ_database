﻿<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>기구 정보</title>
  </head>
  <body>
    <?php
      $conn = mysqli_connect("localhost","root","") ;
      $dbname="mydb";
      mysqli_select_db($conn,$dbname); 
    ?>

<!doctype html>
<html>
<head>

</head>
<body>

  <style>
      body {
        font-family: Consolas, monospace;
        font-family: 12px;
      }
      table {
        width: 100%;
      }
      th, td {
        padding: 10px;
        border-bottom: 1px solid #dadada;
        text-align: center;
      }
    </style>

<article>
   

	<center><h1> 기구 정보 </h1></center>

          <table>
            <tr>
              <th>
                ID
              </th>
              <th>
                기구 이름
              </th>
              <th>
                 A/S
              </th>
              <th>
                기구 삭제
              </th>
            </tr>
            <?php
              $sql = "SELECT * FROM fitness_e";    
              $result = mysqli_query($conn,$sql);

              while($row = mysqli_fetch_assoc($result)){
                $ID = $row['F_id'];
                $name = $row['Name'];
                $as = $row['as'];
               
                echo "
                    <tr>
                      <td>
                        {$ID}
                      </td>
                      <td>
                        {$name}
                      </td>
                      <td>
                        {$as}
                      </td>
                       <td>
                      
                        <form method='POST' action='./delete.php'>
                        <input type='hidden' name='fitness' value='{$ID}'>
                        <input type='submit' style='width:80px; height:30px; background-color:white; border-color:black; border-radius:30px;' value='기구 삭제'>
                      
		</form>

		</td>
                    </tr>
                ";
              }

            ?>
<a href="equip_reg.php"><button style='width:80px; height:30px; background-color:white; border-color:black; border-radius:30px;'>기구 등록</button></a>


 </article>  
</html>
</body>
