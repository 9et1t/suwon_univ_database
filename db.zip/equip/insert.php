﻿<?php
  $name = $_POST['name'];
  $as = $_POST['as_date'];
  $conn = mysqli_connect("localhost","root","");
  $dbname="mydb";
  mysqli_select_db($conn,$dbname);
  $sql = " INSERT INTO `mydb`.`fitness_e` (`Name`, `as`) VALUES ('$name', '$as');";
  $result = mysqli_query($conn,$sql);
  echo "<script>alert('기구가 등록되었습니다.'); location.href=('./equip_reg.php');</script>";

?>
