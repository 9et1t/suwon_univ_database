﻿<?php
$e_name = $_POST['equip_name'];
$s_name = $_POST['staff_name'];
$c_name = $_POST['company_name'];
$date =$_POST['check_date'];
$conn = mysqli_connect("localhost","root","");
$dbname="mydb";
mysqli_select_db($conn,$dbname);

$sql1= "select F_id from fitness_e where name='$e_name'";

	

$sql2= "select idStaff from staff where name='$s_name'";

$result1 = mysqli_query($conn,$sql1);
$result2 = mysqli_query($conn,$sql2);


$row1 = mysqli_fetch_assoc($result1);
$row2 = mysqli_fetch_assoc($result2);

$a=$row1['F_id'];
$b=$row2['idStaff'];
$sql= "INSERT INTO s_check(Fitness_E_F_id,Staff_idStaff,company,date) VALUES ('$a','$b','$c_name','$date')";

$result3 = mysqli_query($conn,$sql);

 

  echo "<script>alert('점검 완료'); location.href=('./check_reg.php');</script>";

?>