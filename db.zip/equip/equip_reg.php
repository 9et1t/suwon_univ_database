﻿ <?php
      $conn = mysqli_connect("localhost","root","") ;
      $dbname="mydb";
      mysqli_select_db($conn,$dbname); 
    ?>

<!doctype html>
<head>
<meta charset="UTF-8">
   <form action="./insert.php" method="post" enctype="multipart/form-data">
	<h1>기구 등록</h1>
      <b>이  름 &nbsp&nbsp <input type="text" name="name" required></b></br></br>
      <b>A/S &nbsp&nbsp&nbsp <input type="date" name="as_date" required></b></br></br>
      <input type='submit' style='width:80px; height:30px; background-color:white; border-color:black; border-radius:30px;' value='기구 등록'  > 
       
	</form>
	<br>
	<a href="equip_list.php"><button style='width:80px; height:30px; background-color:white; border-color:black; border-radius:30px;'>LIST</button></a>

	</head>
	</html>

