﻿
<!doctype html>
<html>
<head>

</head>
<body>

<div id = "manage_button">
            
	<center><input type="button" style="width:200px; height:200px; background-color:pink; border-color:pink; border-radius:30px;" onclick="location.href='./equip_reg.php'"; value="기구 등록" >
            <input type="button" style="width:200px; height:200px; background-color:pink; border-color:pink; border-radius:30px;" onclick="location.href='./equip_list.php'"; value="기구 LIST" >
	<br>	
	<input type="button" style="width:200px; height:200px; background-color:pink; border-color:pink; border-radius:30px;" onclick="location.href='./check_reg.php'"; value="안전 점검" >
            <input type="button" style="width:200px; height:200px; background-color:pink; border-color:pink; border-radius:30px;" onclick="location.href='./check_list.php'"; value="점검 LIST" >


</html>
</body>