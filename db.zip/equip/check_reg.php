﻿<?php
      
      $conn = mysqli_connect("localhost","root","") ;
      $dbname="mydb";
      mysqli_select_db($conn,$dbname); 
    
?>

<!doctype html>
<head>
<meta charset="UTF-8">
	<h1>안전 점검</h1>
   <form action="./check.php" method="post" enctype="multipart/form-data">
       <div class = 'dropdown_container'> 

<b>기구 이름 &nbsp</b>
       <select class="dropdown select xs-mt1" name="equip_name" id="line"> 
       <?php
              $sql = "select name from fitness_e";
              $result = mysqli_query($conn,$sql);
              while ($row = mysqli_fetch_assoc($result)) {
                     echo "<option value='{$row["name"]}'>{$row["name"]}</option>";
              } 
       ?>
       </select> 
      </br></br>
      </div>

 <div class = 'dropdown_container'> 

<b>직원 이름 &nbsp</b>
       <select class="dropdown select xs-mt1" name="staff_name" id="line"> 
       <?php
              $sql = "select name from staff";
              $result = mysqli_query($conn,$sql);
              while ($row = mysqli_fetch_assoc($result)) {
                     echo "<option value='{$row["name"]}'>{$row["name"]}</option>";
              } 
       ?>
       </select> 
      </br></br>
      </div>

      <b>점검 회사 &nbsp<input type="text" name="company_name" required></b></br></br>
      <b>점검일 &nbsp&nbsp&nbsp&nbsp<input type="date" name="check_date" required></b></br></br>
      <input type='submit' style='width:80px; height:30px; background-color:white; border-color:black; border-radius:30px;' value='점검 등록'  > 
      
	</form>
	<br>
	<a href="check_list.php"><button style='width:80px; height:30px; background-color:white; border-color:black; border-radius:30px;'>LIST</button></a>

</html>
</head>