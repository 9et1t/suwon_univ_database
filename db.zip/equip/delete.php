﻿<?php
  $ID = $_POST['fitness'];
  $conn = mysqli_connect("localhost","root","") ;   
  $dbname="mydb";
  mysqli_select_db($conn,$dbname);
  $sql = "DELETE FROM fitness_e where F_id = '{$ID}'";    
  $result = mysqli_query($conn,$sql);
  echo "<script>alert('기구를 삭제했습니다.'); location.href=('./equip_list.php');</script>";

?>
