﻿<!doctype html>
<head>
<meta charset="UTF-8">
<title>관리자 페이지</title>
</head>
<?php
session_start();
if( $_SESSION['id' ]!= "admin" )
{
   echo "<script>window.alert('only admin can access');</script>"; // 잘못된 아이디 또는 비빌번호 입니다
   echo "<script>location.href='/db/customer/login.php';</script>";
}
?>
<body>
<div id ="admin_area">

관리자가 로그인 하셨습니다.
<h1>관리자 페이지입니다.</h1>

<div id="btn_1">
    <a href="./instructor/ins.php"><button>직원관리</button></a>
</div>

<div id="btn_1">
    <a href="./member/mem.php"><button>회원관리</button></a>
</div>

<div id="btn_1">
    <a href="./lecture/lec.php"><button>수강관리</button></a>
</div>

<div id="btn_1">
    <a href="./equip/equip.php"><button>기구관리</button></a>
</div>
</body>
</html>
