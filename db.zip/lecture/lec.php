﻿<!doctype html>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <title>Member</title>
    <style>
      body {
        font-family: Consolas, monospace;
        font-family: 12px;
      }
      table {
        width: 100%;
      }
      th, td {
        padding: 10px;
        border-bottom: 1px solid #dadada;
        text-align: center;
      }
    </style>
  </head>
  <body>
    <table>
      <thead>
        <tr>
          <th>강좌명</th>
          <th>강사</th>
          <th>시작시간</th>          
          <th>종료시간</th>
          <th>가격</th>
          <th>요일</th>
          <th>수정</th>
          <th>삭제</th>
        </tr>
      </thead>
      <tbody>
        <center><h1> 강의 정보 </h1></center>
        <?php
          ini_set('display_errors', '0');
          include "./db1.php";
          

          $jh_sql = "SELECT * FROM lesson LIMIT 15;";
          $jh_result = mysqli_query( $jh_conn, $jh_sql );
          while( $jh_row = mysqli_fetch_array( $jh_result ) ) {
            $jh_edit = '
              <form action="lec_edit.php" method="POST">
                <input type="hidden" name="edit_lec_no" value="' . $jh_row[ 'ID' ] . '">
                <input type="submit" value="Edit" style="width:50px; height:25px; background-color:white; border-color:black; border-radius:30px;">
              </form>
            ';
            $jh_delete = '
              <form action="lec.php" method="POST">
                <input type="hidden" name="delete_lec_no" value="' . $jh_row[ 'ID' ] . '">
                <input type="submit" value="Delete" style="width:60px; height:25px; background-color:white; border-color:black; border-radius:30px;">
              </form>
            ';
           $a=$jh_row['Staff_idStaff'];
           $sql1 = "select name from staff where idStaff='$a'";
           $result1 = mysqli_query($jh_conn,$sql1);
           $row1 = mysqli_fetch_assoc($result1);
           $b = $row1['name'];

           // echo '<tr><td>' . $jh_row[ 'ID' ] . '</td><td>'. $jh_row[ 'Lesson_ID' ] . '</td><td>' . $jh_row[ 'name' ] . '</td><td>' . $jh_row[ s_date' ] . '</td><td>' . $jh_edit . '</td><td>' . $jh_delete . '</td></tr>';
              echo '</td><td>' . $jh_row['name'] . '</td><td>' . $b . '</td><td>' . $jh_row['s_time'] . '</td><td>' . $jh_row['e_time'] . '</td><td>' . $jh_row['price'] . '</td><td>' . $jh_row['day'] . '</td><td>' . $jh_edit . '</td><td>' . $jh_delete . '</td></tr>';
          }
          $delete_lec_no = $_POST[ 'delete_lec_no' ];
          if ( isset( $delete_lec_no ) ) {
            $jh_sql_delete = "DELETE FROM lesson WHERE ID = '$delete_lec_no';";
            mysqli_query( $jh_conn, $jh_sql_delete );
          }
        ?>
      </tbody>
    </table>
    <br/>&nbsp&nbsp&nbsp
    <button type="button"  style='width:80px; height:30px; background-color:white; border-color:black; border-radius:30px;'onclick="location.href='lec_reg.php' ">강의등록</button>
  </body>
</html>