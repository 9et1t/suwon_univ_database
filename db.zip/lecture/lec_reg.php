﻿<?php

include "./db1.php";

?>
<!doctype html>
<head>
<meta charset="UTF-8">
<title>lesson_reg</title>

<form action="lec_reg_ok.php" method="post" enctype="multipart/form-data">
<h1>강의 등록</h1>
<b>강사명</b>
       <select class="dropdown select xs-mt1" name="Staff_name"> 
       <?php
              $sql = "select name from staff";
              $result = mysqli_query($jh_conn,$sql);
              while ($row = mysqli_fetch_assoc($result)) {
                     echo "<option value='{$row["name"]}'>{$row["name"]}</option>";
              }
       ?>
       </select> 
</b></br></br>
      <b>강의명&nbsp <input type="text" name="name" </b></br></br>
      <b>시작시간 <input type="time" name="s_time" </b></br></br>
      <b>종료시간 <input type="time" name="e_time" </b></br></br>
      <b>가격 <input type="text" name="price" </b></br></br>
      <b>요일 <input type="text" name="day" </b></br></br>
      <input type='submit' style='width:80px; height:30px; background-color:white; border-color:black; border-radius:30px;' value='등록 완료'  > 

   </form>
</html>
