﻿<?php
  include "./db1.php";
  $edit_lec_no = $_POST[ 'edit_lec_no' ];
  $jh_sql_edit = "SELECT * FROM lesson WHERE ID = $edit_lec_no;";
  $jh_result = mysqli_query( $jh_conn, $jh_sql_edit );
  $jh_row = mysqli_fetch_array( $jh_result );
?>
 
<!doctype html>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <title>Member edit</title>
    <style>
      body {
        font-family: Consolas, monospace;
        font-family: 12px;
      }
    </style>
  </head>
  <body>
<form action="lec_edit_ok.php" method="post" enctype="multipart/form-data">
<h1>강의 수정</h1>
<b>강사명</b>
       <select class="dropdown select xs-mt1" name="Staff_name"> 
       <?php
              $sql = "select name from staff";
              $result = mysqli_query($jh_conn,$sql);
              while ($row = mysqli_fetch_assoc($result)) {
                     echo "<option value='{$row["name"]}'>{$row["name"]}</option>";
              }
       ?>
       </select> 
      <input type="hidden" name="lec_no" value="<?php echo $jh_row[ 'ID' ]; ?>"></br></br>
      <b>강의명&nbsp <input type="text" name="name" value="<?php echo $jh_row[ 'name' ]; ?>" required></b></br></br>
      <b>시작시간 <input type="time" name="s_time" value="<?php echo $jh_row[ 's_time' ]; ?>" required></b></br></br>
      <b>종료시간 <input type="time" name="e_time" value="<?php echo $jh_row[ 'e_time' ]; ?>" required></b></br></br>
      <b>가격 <input type="text" name="price" value="<?php echo $jh_row[ 'price' ]; ?>" required></b></br></br>
      <b>요일 <input type="text" name="day" value="<?php echo $jh_row[ 'day' ]; ?>" required></b></br></br>
      <input type='submit' style='width:80px; height:30px; background-color:white; border-color:black; border-radius:30px;' value='수정 완료'  > 

   </form>
</html>