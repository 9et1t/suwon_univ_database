﻿<?php
include "./db1.php";
?>

<!doctype html>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <title>Update Member</title>
    <style>
      body {
        font-family: Consolas, monospace;
        font-family: 12px;
      }
    </style>
  </head>
  <body>
    <?php
      $lec_no = $_POST[ 'lec_no' ];
      $name = $_POST[ 'name' ];
      $s_time = $_POST[ 's_time' ];
      $e_time = $_POST[ 'e_time' ];
 $price = $_POST[ 'price' ];
 $day = $_POST[ 'day' ];
 $Staff_name = $_POST[ 'Staff_name'];
    

      $sql1 = "select idStaff from staff where name='$Staff_name'";
      $result1 = mysqli_query($jh_conn,$sql1);
      $row1 = mysqli_fetch_assoc($result1);
      $a = $row1['idStaff'];

      if ( is_null( $lec_no ) ) {
        echo '<h1>Fail!</h1>';
      } else {
        $jh_sql = "UPDATE lesson SET name = '$name', Staff_idStaff = $a, s_time = '$s_time', e_time = '$e_time', price = '$price', day = '$day' WHERE ID = $lec_no;";
        mysqli_query( $jh_conn, $jh_sql );
      }
    ?>
<meta http-equiv="refresh" content="0; url=./lec.php">
  </body>
</html>