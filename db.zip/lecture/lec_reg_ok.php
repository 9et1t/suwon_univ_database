﻿<?php
include "./db1.php"
?>
<!doctype html>
<html>
<?php

$name=$_POST['name'];
$Staff_name=$_POST['Staff_name'];
$stime=$_POST['s_time'];
$etime=$_POST['e_time']; 
$price=$_POST['price'];
$day=$_POST['day'];

$sql1 = "select idStaff from staff where name='$Staff_name'";
$result1 = mysqli_query($jh_conn,$sql1);
$row1 = mysqli_fetch_assoc($result1);
$a = $row1['idStaff'];

$sql = "insert into lesson (name,Staff_idstaff,s_time,e_time,day,price) values ('$name',$a,'$stime','$etime','$day','$price')";

  if($jh_conn->query($sql)){
    echo "<script>alert ('강의 등록이 완료되었습니다.');</script>";
  } 
?>
<meta http-equiv="refresh" content="0; url=./lec.php">
</html>