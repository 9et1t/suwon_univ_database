﻿<?php

include "./db1.php";

?>
<!doctype html>
<head>
<meta charset="UTF-8">
<title>Member_reg</title>
<form action="mem_reg_ok.php" method="post" enctype="multipart/form-data">
<h1>회원 등록</h1>
<b>강의명</b>

       <select class="dropdown select xs-mt1" name="Lesson_ID"> 
       <?php
              $sql = "select name from lesson";
              $result = mysqli_query($jh_conn,$sql);
              while ($row = mysqli_fetch_assoc($result)) {
                     echo "<option value='{$row["name"]}'>{$row["name"]}</option>";
              }
       ?>
       </select> 
      <p>이  름 &nbsp&nbsp<input type="text" name="name" required></p>
      <p>시작일 <input type="date" name="s_date" required></p>
      <p>마감일 <input type="date" name="e_date" required></p>
      <p>핸드폰 <input type="text" name="M_phone" required></p>
      <input type='submit' style='width:80px; height:30px; background-color:white; border-color:black; border-radius:30px;' value='회원 등록'  >
 
   </form>
</html>

