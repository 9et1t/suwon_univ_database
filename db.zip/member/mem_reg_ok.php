﻿<?php
include "./db1.php"
?>
<!doctype html>
<html>
<?php

$name=$_POST['name'];
$lesson=$_POST['Lesson_ID'];
$sdate=$_POST['s_date'];
$edate=$_POST['e_date']; 
$phone=$_POST['M_phone'];

$sql1 = "select ID from lesson where name='$lesson'";
$result1 = mysqli_query($jh_conn,$sql1);
$row1 = mysqli_fetch_assoc($result1);
$a = $row1['ID'];

$sql = "insert into member (name,Lesson_ID,s_date,e_date,M_phone) values ('$name',$a,'$sdate','$edate','$phone')";

  if($jh_conn->query($sql)){
    echo "<script>alert ('회원 등록이 완료되었습니다.');</script>";
  } 
?>
<meta http-equiv="refresh" content="0; url=./mem.php">
</html>