﻿<?php
include "./db1.php";
?>

<!doctype html>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <title>Update Member</title>
    <style>
      body {
        font-family: Consolas, monospace;
        font-family: 12px;
      }
    </style>
  </head>
  <body>
    <?php
      $mem_no = $_POST[ 'mem_no' ];
      $name = $_POST[ 'name' ];
      $lesson = $_POST[ 'Lesson_ID' ];
      $s_date = $_POST[ 's_date' ];
      $e_date = $_POST[ 'e_date' ];
      $M_phone = $_POST[ 'M_phone' ];

      $sql1 = "select ID from lesson where name='$lesson'";
      $result1 = mysqli_query($jh_conn,$sql1);
      $row1 = mysqli_fetch_assoc($result1);
      $a = $row1['ID'];

      if ( is_null( $mem_no ) ) {
        echo '<h1>Fail!</h1>';
      } else {
        $jh_sql = "UPDATE member SET name = '$name', Lesson_ID = $a, s_date = '$s_date', e_date = '$e_date', M_phone = '$M_phone' WHERE M_id = $mem_no;";
        mysqli_query( $jh_conn, $jh_sql );
      }
    ?>
<meta http-equiv="refresh" content="0; url=./mem.php">
  </body>
</html>