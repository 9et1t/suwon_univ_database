﻿<!doctype html>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <title>Member</title>
    <style>
      body {
        font-family: Consolas, monospace;
        font-family: 12px;
      }
      table {
        width: 100%;
      }
      th, td {
        padding: 10px;
        border-bottom: 1px solid #dadada;
        text-align: center;
      }
    </style>
  </head>
  <body>
    <table>
      <thead>
        <tr>
          <th>강좌명</th>
          <th>회원 이름</th>
          <th>시작일</th>          
          <th>마감일</th>
          <th>핸드폰 번호</th>
          <th>수정</th>
          <th>삭제</th>
        </tr>
      </thead>
      <tbody>
        <center><h1> 회원 정보 </h1></center>
        <?php
          ini_set('display_errors', '0');
          include "./db1.php";
          

          $jh_sql = "SELECT * FROM member LIMIT 15;";
          $jh_result = mysqli_query( $jh_conn, $jh_sql );
          while( $jh_row = mysqli_fetch_array( $jh_result ) ) {
            $jh_edit = '
              <form action="mem_edit.php" method="POST">
                <input type="hidden" name="edit_mem_no" value="' . $jh_row[ 'M_id' ] . '">
                <input type="submit" value="Edit" style="width:50px; height:25px; background-color:white; border-color:black; border-radius:30px;">
              </form>
            ';
            $jh_delete = '
              <form action="mem.php" method="POST">
                <input type="hidden" name="delete_mem_no" value="' . $jh_row[ 'M_id' ] . '">
                <input type="submit" value="Delete" style="width:60px; height:25px; background-color:white; border-color:black; border-radius:30px;">
              </form>
            ';
           $a=$jh_row['Lesson_ID'];
           $sql1 = "select name from lesson where ID='$a'";
           $result1 = mysqli_query($jh_conn,$sql1);
           $row1 = mysqli_fetch_assoc($result1);
           $b = $row1['name'];

           // echo '<tr><td>' . $jh_row[ 'M_id' ] . '</td><td>'. $jh_row[ 'Lesson_ID' ] . '</td><td>' . $jh_row[ 'name' ] . '</td><td>' . $jh_row[ s_date' ] . '</td><td>' . $jh_edit . '</td><td>' . $jh_delete . '</td></tr>';
              echo '</td><td>' . $b . '</td><td>' . $jh_row['name'] . '</td><td>' . $jh_row['s_date'] . '</td><td>' . $jh_row['e_date'] . '</td><td>' . $jh_row['M_phone'] . '</td><td>' . $jh_edit . '</td><td>' . $jh_delete . '</td></tr>';
          }
          $delete_mem_no = $_POST[ 'delete_mem_no' ];
          if ( isset( $delete_mem_no ) ) {
            $jh_sql_delete = "DELETE FROM member WHERE M_id = '$delete_mem_no';";
            mysqli_query( $jh_conn, $jh_sql_delete );
          }
        ?>
      </tbody>
    </table>
    <br/>&nbsp&nbsp&nbsp
    <button type="button"  style='width:80px; height:30px; background-color:white; border-color:black; border-radius:30px;'onclick="location.href='mem_reg.php' ">회원등록</button>
  </body>
</html>