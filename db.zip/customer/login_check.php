﻿<?php

session_start();
 $con = mysqli_connect( 'localhost', 'root', '', 'mydb' );

$name = $_POST['name'];  
$M_phone = $_POST['M_phone'];

if($name=="admin" && $M_phone=="admin")
{
    $_SESSION['id']="admin";
   echo "<script>location.href='../admin.php';</script>";
}
$query = "select * from member where name='$name' and M_phone='$M_phone'";
$result = mysqli_query($con, $query); 
$row = mysqli_fetch_array($result);



if($name==$row['name'] && $M_phone==$row['M_phone']){ // id와 pw가 맞다면 login

   $_SESSION['id']=$row['name'];
   $_SESSION['name']=$row['name'];
   echo "<script>location.href='login.php';</script>";

}else{ // id 또는 pw가 다르다면 login 폼으로

   echo "<script>window.alert('invalid username or password');</script>"; // 잘못된 아이디 또는 비빌번호 입니다
   echo "<script>location.href='login.php';</script>";

}

?>