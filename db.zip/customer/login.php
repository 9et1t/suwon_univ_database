﻿
<!doctype html>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <title>Member</title>
    <style>
      body {
        font-family: Consolas, monospace;
        font-family: 12px;
      }
      table {
        width: 100%;
      }
      th, td {
        padding: 10px;
        border-bottom: 1px solid #dadada;
        text-align: center;
      }
    </style>
  </head>
 
<?php

session_start(); // 세션

if($_SESSION['id']==null) { 
// 로그인 하지 않았다면

?>



<center>
<div align="center"><img src="logo.jpg" ></div>
<br><br><br>

<form name="login_form" action="login_check.php" method="post"> 
   ID : <input type="text" name="name"><br> 
   PW:<input type="password" name="M_phone"><br><br>
   <input type="submit" name="login" value="Login"> 
</form>

</center>


 
<?php


}else{ // 로그인 했다면




if( $_SESSION['name'] == 'admin') {

echo("<script>location.href='b.php';</script>");


} 
 
echo "<br />";

echo "<br />";



echo "&nbsp;<a href='logout.php'><input type='button' value='Logout'></a>";
echo "<br />";



   echo "<center>";

$dateString = date("Y-m-d", time()); 
echo "Today : ";
echo $dateString;
$today = array("일","월","화","수","목","금","토");
echo($today[date('w', strtotime($dateString))]);
echo "<br />";
?>
<h1>
<?php
   echo $_SESSION['name']."님의 강좌 및 회원정보 ";
?>
</h1>

<?php
echo "<br />";


echo "<br />";

   
?>

 <table>
      <thead>
        <tr>
          <th>강좌명</th>
          <th>시작일</th>          
          <th>마감일</th>
          <th>강의 요일</th>
           <th>강의료</th>
        </tr>
      </thead>

<?php
$host = 'localhost';
 $user = 'root';
 $pw = '';
 $dbName = 'mydb';
 $mysqli = new mysqli($host, $user,$pw,$dbName);


 $name=$_SESSION['name'];




echo "<br />";

$sql = "SELECT * FROM member
inner join lesson
on member.Lesson_ID = lesson.ID where member.name = '$name'" 
;

 $res = $mysqli->query($sql);

?>
<tbody>
<?php
while($row = mysqli_fetch_assoc($res)){
echo "<tr>";
echo "<td>" . $row['name'] . "</td>";
echo "<td>" . $row['s_time'] . "</td>";
echo "<td>" . $row['e_time'] . "</td>";
echo "<td>" . $row['day'] . "</td>";
echo "<td>" . $row['price'] . "</td>";
$day = $row['day'] ; 
echo "<br />";
echo "</tr>";
}

?>
</tbody>
</table>

<table>
      <thead>
        <tr>
          <th>회원</th>
          <th>시작일</th>          
          <th>마감일</th>
          <th>연락처</th>
           <th></th>
        </tr>
      </thead>

<?php


$sql = "SELECT * FROM member
where name ='$name'" 
;

$res = $mysqli->query($sql);

while($row = mysqli_fetch_assoc($res)){


echo "<br />";

?>
<tbody>
<?php

echo "<td>" . $row['name'] . "</td>";
echo "<br />";
echo "<td>" . $row['e_date'] . "</td>";
echo "<td>" . $row['s_date']. "</td>";
echo "<br />";

echo "<td>" . $row['M_phone'] . "</td>";
echo "<br />";

?>
</tbody>
</table>
<?php
}      


$todaya = $today[date('w', strtotime($dateString))];

if ((strpos($day, $todaya) == false)) echo "오늘은 수업이 없습니다.  ";
else echo"수업이 있습니다";


$sql = "SELECT * FROM lesson
inner join member
on lesson.ID = member.Lesson_ID where member.name ='$name' and lesson.day = '$todaya'" 
;


$res = $mysqli->query($sql);

while($row = mysqli_fetch_assoc($res)){



$idid = $row['ID'];

echo "Today's Lesson :" ;
switch ($idid) {

}
}



$sql = 'SELECT * FROM lesson';

$res = $mysqli->query($sql);
 
$row = mysqli_fetch_array($res);

if(  $row["day"]=$dateString){

$day = $row["day"];

}










 






   
echo "</center>";
}

?>
</html>